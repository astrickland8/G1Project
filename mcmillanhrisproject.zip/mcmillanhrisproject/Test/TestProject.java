import org.junit.Assert;
import org.junit.Test;

public class TestProject  {

    @Test
     public void TestProject () {
        String myUrl = "jdbc:mysql://127.0.0.1:3306/mcmillanhrisproject";
        String user = "root";
        String password = "Saima1977";
        ProjectG pro = new ProjectG(myUrl, user, password);
        String qInsert = " INSERT INTO employees (firstname, lastname, emp_address, city, zip, manager_id, department_id)" +
    " VALUES ('Cardinal', 'Tom', 'Skagen 21', 'Stavanger', '4006', '23','7')";
       int result = pro.Query_insert(qInsert); // query to add new data
        Assert.assertTrue("record row successfully added.",result > 0);

        String getread = "select  firstname, lastname, emp_address, city, zip, manager_id, department_id from employees";
        int result_count = pro.Query_read_get_resultSet(getread);
        Assert.assertTrue("record row successfully read.",result_count > 0);




        String qdelete = "DELETE FROM employees WHERE firstname ='Cardinal'   ";
       int deleteq = pro.Query_delete(qdelete); // query to delete entered new data
        Assert.assertTrue("record deleted successfully.",deleteq > 0);


    }




    }
