import java.sql.*;


public class ProjectG { //variables
    String myUrl;
    String user;
    String password;
    Connection conn;
    Statement st;

    public ProjectG(String myUrl, String user, String password) {
        //  constructor
        //this.myUrl = "jdbc:mysql://127.0.0.1:3306/mcmillanhrisproject";
        this.myUrl = myUrl;
        this.user = user;
        this.password = password; // setting attributes for as per given parameters
    }
    public void Query_read ()  {
        create_conn(); // method to set connection with database and set statment to enter query

        try {
            // try/catch method be in connection
            String query_read = "SELECT * FROM employees"; //this query is for read as default , it can be parameterize
            ResultSet rs;// for holding  result data after select  query
            rs = this.st.executeQuery(query_read);
            //Statement st = conn.createStatement();
            while (rs.next()) { // we have to iterate through result set and caputre the value for a sigle or multiple column
                int id = rs.getInt("employee_id"); // it can be parameterize
                String firstName = rs.getString("firstname");
                String lastName = rs.getString("lastname");
//             //Date dateCreated = rs.getDate("date_created");
//             //boolean isAdmin = rs.getBoolean("is_admin");
//             //int numPoints = rs.getInt("num_points");
//
//             print the results
                System.out.format("%s, %s \n", firstName, lastName); //format statement to dispaly the result
//          }

            }
            close_conn(); //we need to close all the connection for better data response
        }catch (Exception e) {
            throw new RuntimeException(e);
        }

    }
    public void Query_insert () {
        create_conn();
        try {
            String query = " INSERT INTO employees (firstname, lastname, emp_address, city, zip, manager_id, department_id) " +
                    "VALUES ('Cardinal', 'Tom', 'Skagen 21', 'Stavanger', '4006', '23','7')";
            int n = this.st.executeUpdate(query);
            System.out.println(" Number of rows affected: " + n);
            close_conn();
        }
        catch ( Exception e ) {
            System.err.println("Got an exception! " + e) ;
      }

  }
    public void Query_update () {
    create_conn();
    try{
        String query = " UPDATE employees SET firstname ='Allen' WHERE city ='saima'";
            int n = this.st.executeUpdate(query);
            System.out.println(" Number of rows affected: " + n);
            close_conn();
        }
        catch ( Exception e ) {
            System.err.println("Got an exception! " + e) ;
        }

   }
    public void Query_delete (){
     create_conn();
     try{
          String query = " DELETE FROM employees WHERE firstname ='Athena'  ";
          int n = this.st.executeUpdate(query);
          System.out.println(" Number of rows affected: " + n);
          close_conn();
      }
      catch ( Exception e ) {
          System.err.println("Got an exception! " + e) ;
      }
  }
    public void create_conn( ){
      try {
          //this.myUrl = "jdbc:mysql://127.0.0.1:3306/mcmillanhrisproject";
          //this.user = user;
          //this.password = password;
          this.conn = DriverManager.getConnection(this.myUrl, this.user, this.password);
          this.st = this.conn.createStatement();
      } catch (Exception e) {
          System.err.println("Got an exception during creating connection! " + e) ;
      }
    }
    public void close_conn() {
         try {
             this.st.close();
             this.conn.close();
         } catch (Exception e) {
             System.err.println("Got an exception during closing connections! ");
             System.err.println(e.getMessage());
         }


 }


   }






