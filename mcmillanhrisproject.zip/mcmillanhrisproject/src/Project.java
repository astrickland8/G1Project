import java.sql.*;


public class Project {
    public static void main(String[] args) throws SQLException {
       String myUrl = "jdbc:mysql://127.0.0.1:3306/mcmillanhrisproject";;// update your url here
       String user  = "root"; // update your user name here
       String password = "xxxxxx"; // update your password here

       ProjectG project = new ProjectG(myUrl, user,  password);
       project.Query_read();
       project.Query_insert();
       project.Query_update();
       project.Query_delete();

    }
}
