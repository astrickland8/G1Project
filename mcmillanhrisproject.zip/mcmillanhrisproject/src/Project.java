import java.sql.*;


public class Project {
    public static void main(String[] args) throws SQLException {
        // create  mysql database connection
       String myUrl = "jdbc:mysql://127.0.0.1:3306/mcmillanhrisproject";;// update your url here
       String user  = "root"; // update your user name here
       String password = "Saima1977"; // update your password here

       ProjectG project = new ProjectG(myUrl, user,  password);

        String inputquery = "select employee_id, firstname from employees where employee_id = 1";



        project.Query_read(inputquery);
      //project.Query_insert();
       //project.Query_update();
       //project.Query_delete();

    }
}
